package common;

public record Substitution(String parameterName1,String type1,
                           String parameterName2,String type2) {
    public Substitution{ }
}
